from django.contrib import admin
from .models import *

admin.site.register(Users)
admin.site.register(Novel)
admin.site.register(Fanfics)
admin.site.register(Genre)